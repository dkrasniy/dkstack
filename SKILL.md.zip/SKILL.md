---
name: write-docs-like-dkrasniy
description: Write or revise technical documentation in David's (dkrasniy) docs style — READMEs, conceptual explainers, how-to guides and reference pages that are easy to read the first time through. Use when he asks to "write docs like dkrasniy", "in my docs style", "write the README/docs", or invokes /write-docs-like-dkrasniy. Covers page types, page structure, sentence-level prose rules and accuracy checks. For casual chat replies in his voice, use talk-like-david instead; docs never use that casual register.
---

# Write docs like dkrasniy

You're writing technical documentation that's easy to read the first time through. The reader
is a capable engineer who hasn't seen this code. Explain what it does, why it works that way,
and what they should do, in that order.

Before writing, read the code the docs describe. Every claim has to match it.

## Pick the page type first

Every page is exactly one of these. Don't mix them.

- **README**: what it is in two or three sentences, what it produces (often a directory
  tree), the shortest path to using it, then links to the other pages.
- **Conceptual** ("Overview of …", "Rendering …"): explains how something works and why.
  It teaches; it doesn't give steps.
- **How-to** (titled so it reads after "How to"): Introduction (2–3 sentences),
  Prerequisites (bullets), Directions (`### Step 1: …`, one action per step),
  Additional resources.
- **Reference**: looked up, not read through. A one-line intro, then tables
  (`Option | Type | Default | Description`), then exact lists such as output files and
  headers.

A package's docs usually come as a README, then `docs/` holding one overview, a few
conceptual pages, one how-to per common task, and one reference page.

## Page structure

- Open conceptual pages with an italic scope line that points elsewhere for detail:
  _This is a high-level look at X. For every option, see [the reference](reference.md)._
- Place the topic in the bigger picture first, then define it in one sentence.
- Concepts before procedures. Use question headings where they fit: "Why render at build
  time?", "How does the renderer use components?", "Is it worth it?".
- Use sentence-case headings, H2 for sections and H3 for parts. No H1 in the body.
- When there's command output, paste a real run, then use each output line as an H3 and
  explain it in 2–4 sentences. Show a second run as a `diff` when comparing.
- Use a `text` directory tree for anything that produces files.
- Show restrictions as a rule sentence, then paired code examples marked `// OK:` and
  `// ⚠️ Doesn't work:` with the reason, then what to do instead.
- Use `> **Note:**` for the one thing the reader would otherwise get wrong. Use it rarely.
- End conceptual pages and how-tos with "Additional resources": descriptive links, never
  "here".

## Sentences

- Write to "you". Use present tense and active voice: "The renderer writes…", not "files
  are written…".
- Keep paragraphs to one to four sentences, one idea each. A sentence carries one or two
  facts.
- Put the reason in the same sentence as the fact: "A signed URL expires, so it can't go
  into a built page." Connect cause and effect with "so", "since" and "That's why".
- Define a term in _italics_ the first time, in plain words: "That is called _hydration_."
- Be concrete. Use real names, real numbers and real output: "a 1600px image becomes 640,
  828, 1080 and 1600". Avoid "various sizes".
- Say what happens when things go wrong: what's reported, what's skipped, what the reader
  sees.
- State limits plainly, with the workaround: "Browsers don't run modules from disk. To try
  interactive blocks, serve the site over HTTP."
- Use contractions (it's, doesn't, can't). They read like a person.
- Put a condition first when the reader may skip: "If you know where the site will be
  served, pass `--base-path`."
- Lists in a sentence take no comma before "and" or "or": "styles, fonts and images".
- Bullets are for parallel items. Start each with the thing it describes: "`--drafts`
  builds each page from your draft of it."

## Never

- "easy", "simple", "simply", "just", "obviously", "of course", "note that", "it's worth
  noting"
- Openers that announce the page: "In this section we will…", "This document describes…"
- Em dashes. Use a period, a comma or a colon.
- Metaphors, marketing words ("powerful", "seamless", "blazing"), exclamation marks, emojis
  in prose
- Hedging such as "might possibly", "should generally" or "in some cases". Say when it
  applies.
- Restating the heading in the first sentence
- Bold for emphasis inside sentences. Bold is only for labels at the start of a bullet.

## Accuracy

- Every claim must match the code or the real behavior. Check before you write it. If you
  haven't tested something, say so, or leave it out.
- Prefer one exact example over an abstract description. Paste real command output and real
  file names rather than invented ones.
- Link to the deeper page instead of repeating it. Each fact lives on one page.
- After the code changes, reread the docs that describe it. A doc that says the old
  behavior is a bug.

## Before you finish

Reread each page once as a newcomer and check:

1. Does the first paragraph say what this is and why the reader would care?
2. Could they follow every step without asking a question?
3. Does any sentence break a "Never" rule above?
4. Is every claim true of the code as it is now?
